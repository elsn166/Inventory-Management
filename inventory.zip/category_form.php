<div class="row">
        <div class="col-12">
            <div class="">
               <form  name="frmContact" method="POST" action="customer2.php">
                    <div class="row my-3">
                        
                        <div class="col-12 col-lg-6">
                          <h6>category</h6>
  
                          <div class="form-outline input-group">
                               <input type="text" name="category" placeholder="category" class="form-control">
                          </div>
                        </div>
                        
                       <div class="col-12 col-lg-6">
                          <h6>Model</h6>
                          <div class="form-outline input-group">
                              <input type="text" name="model" placeholder="Model" class="form-control"  required>
                          </div>
                        </div>
                    </div>
  
                    <div class="row my-3">
                        <div class="col-12 col-lg-6">
                          <h6>Product Code</h6>
  
                          <div class="form-outline input-group">
                             <input type="text" name="ProductCode" placeholder="Product Code" class="form-control"  required>
                              <!-- <label class="form-label" for="form12">Example label</label> -->
                          </div>
                        </div>
                      <div class="col-12 col-lg-6">
                        <h6>Price</h6>
  
                        <div class="form-outline input-group">
                            <input  type="text" name="price" placeholder="Price"  class="form-control"  required>
                            <!-- <label class="form-label" for="form12">Example label</label> -->
                        </div>
                      </div>
                  </div>
  
                  <div class="row my-3">
                     <div class="col-12 col-lg-6">
                        <h6>MRP</h6>
  
                        <div class="form-outline input-group">
                            <input type="text" name="mrp" placeholder="MRP"  class="form-control" required>
                            <!-- <label class="form-label" for="form12">Example label</label> -->
                        </div>
                      </div>
                      <div class="col-12 col-lg-6">
                        <h6>Warranty</h6>
                          <div class="form-outline input-group">
                            <input type="text" name="Warranty" placeholder="Warranty"  class="form-control" required>
                            <!-- <label class="form-label" for="form12">Example label</label> -->
                        </div>
                      </div>
                  </div>

                  <div class="product_submit">
                      <button type="submit" class="btn btn-primary" id="">Submit</button>
                  </div>
                </form>
        
                    </div>

          </div>
        </div>