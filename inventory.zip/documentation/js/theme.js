 $(window).load(function() {
    $('.flexslider').flexslider({
        controlNav: true, 
        directionNav: false
    });
  });