<?php
$servername ="localhost";
$username ="u488219384_inventory";
$password ="Inventory@123";
$dbname ="u488219384_inventory";
?>