
!function($) {
    "use strict";

   

}(window.jQuery);