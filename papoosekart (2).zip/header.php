<style>
  @media only screen and (max-width: 600px) {
   .btn1{
   display:none;
  }
}
</style>
                    <div class="row">
                        <div class="col-12 col-sm-12 px-0">
                            <div class="form-group mb-0 position-relative search-bar">
                               <input type="text" class="form-control" disabled  placeholder="" />
                            <div class="btn-search btn1 position-absolute">
                            <div class="dropdown">
                             <img src="dist/images/user2-160x160.jpg" alt="" class=" dropdown-toggle rounded-circle mb-5"   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" width="50">
                              <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <a class="dropdown-item" href="index.php">Log Out</a>
                               <!--<a class="dropdown-item" href="#">Another action</a>
                                <a class="dropdown-item" href="#">Something else here</a>-->
                              </div>
                            </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row my-4">
                        <div class="col-12 col-sm-6 order-lg-1 order-2 text-right text-lg-left">
                            <div class="navbar-header">
                                <button type="button" class="navbar-btn rounded sidebarCollapse">
                                    <span class="ion-navicon"></span>
                                </button>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 order-lg-2 order-1 align-self-center">
                            <ol class="breadcrumb mb-0 bg-transparent eagle-light p-0 justify-content-lg-end justify-content-start">
                                <li class="breadcrumb-item"><a href="dashbord.php" class="eagle-light">Home</a></li>
                                <li class="breadcrumb-item active">Dashboard </li>
                            </ol>
                        </div>
                    </div>