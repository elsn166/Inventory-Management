<?php
$servername ="127.0.0.1:3306";
$username ="u309950752_papoosekart";
$password ="Papoosekart123";
$dbname ="u309950752_papoosekart";
?>