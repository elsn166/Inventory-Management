           <div class="right-sidebar bg-white d-none d-lg-inline-block">
                <div class="right-sidebar-scrollarea">
                    <div class="sidebar-details sidebar-header">
                        <ul class="list-inline notification mb-0">
                            <li class="list-inline-item dropdown">
                                <a  class="nav-link position-relative" data-toggle="dropdown" aria-expanded="false"><span class="ion ion-ios-email-outline"></span>
                                    <span class="badge badge-pill badge-danger">5</span>
                                </a>
                                <ul class="dropdown-menu border-0 py-0">
                                    <li><a class="dropdown-item" href="#">
                                        <strong>John Smith</strong>
                                        <small class="eagle-light d-block">11 am John Smith Ckeck My...</small>
                                        </a></li>
                                    <li><a class="dropdown-item" href="#">
                                        <strong>Daniel Luke</strong>  
                                        <small class="eagle-light d-block">Can You Send Me your Bugdet...</small>
                                    </a></li>
                                    <li><a class="dropdown-item" href="#">
                                        <strong>Adam Kruel</strong> 
                                        <small class="eagle-light d-block">Heelo! I need best web design...</small>
                                    </a></li>
                                    <li><a class="dropdown-item text-center" href="#"> <b>Read All Message</b> </a></li>
                                </ul>
                            </li>
                            <li class="list-inline-item dropdown">
                                <a  class="nav-link position-relative" data-toggle="dropdown" aria-expanded="false"><span class="ion ion-ios-bell-outline"></span>
                                    <span class="badge badge-pill badge-danger">9</span>
                                </a>
                                <ul class="dropdown-menu border-0 py-0">
                                    <li><a class="dropdown-item" href="#">
                                        <span>Hello I'm Meryam</span>
                                        <small class="eagle-light d-block">2 min ago.</small>
                                    </a></li>
                                    <li><a class="dropdown-item" href="#">
                                        <span>Hello I'm Daniel</span>
                                        <small class="eagle-light d-block">12 min ago.</small>
                                    </a> </li>
                                   <li> <a class="dropdown-item" href="#">
                                        <span>Hello I'm Adam Kruel</span>
                                        <small class="eagle-light d-block">5 min ago.</small>
                                    </a></li> 
                                    <li><a class="dropdown-item text-center" href="#"> <b>Show All Notification</b> </a></li>
                                </ul> 
                            </li>
                            <li class="list-inline-item">
                               
                                    <select class="selectpicker" data-width="fit">
                                        <option data-content='<span><img src="dist/images/eng.jpg" class="img-fluid" /></span> English'>English</option>
                                        <option  data-content='<span><img src="dist/images/span.jpg" class="img-fluid" /></span> Sprnish'>Sprnish</option>
                                        <option data-content='<span><img src="dist/images/russi.jpg" class="img-fluid" /></span> Russian'>Russian</option>
                                        <option  data-content='<span><img src="dist/images/china.jpg" class="img-fluid" /></span> Chinese'>Chinese</option>
                                    </select>
                               
                            </li>                        
                        </ul>
                    </div>
                    <div class="sidebar-details py-4">
                        <div class="media">
                            <img src="dist/images/author1.jpg" alt="" class="d-flex mr-3 img-fluid eagle-rounded-circle-50 align-self-center" width="50">
                            <div class="media-body align-self-center eagle-line-height-1_5">
                                <div class="btn-group float-right">
                                    <a href="" class="drop-btn text-white text-center eagle-rounded-circle-50 eagle-bg-primary" data-toggle="dropdown"><small> <i class="ion ion-arrow-down-b"></i> </small></a>
                                    <div class="dropdown-menu bg-white border-0">
                                        <a class="dropdown-item" href="#"><i class="icofont icofont-ui-edit text-success pr-2"></i> Edit</a>
                                        <a class="dropdown-item" href="#"><i class="icofont icofont-close-circled text-danger pr-2"></i> Delete</a>
                                        <a class="dropdown-item" href="#"><i class="icofont icofont-shield-alt text-warning pr-2"></i> Cancel</a>
                                    </div>
                                </div>
                                <span class="text-uppercase lato">John Deo</span>
                                <small class="text-primary d-block">Admin</small>
                            </div>
                        </div>
                    </div>
                    <div class="sidebar-details py-4 text-center">
                        <ul class="list-inline mb-0 lato element-box">
                            <li class="list-inline-item mr-3">
                                <a href="#" class="eagle-light">
                                    <span class="btn-add text-white"><i class="ion ion-android-add rounded eagle-bg-success"></i></span>
                                    <span class="d-block">Add New</span>
                                </a>
                            </li> 
                            <li class="list-inline-item mr-3">
                                <a href="#" class="eagle-light">
                                    <span class="btn-add text-white"><i class="ion ion-ios-chatboxes-outline rounded eagle-bg-primary"></i></span>
                                    <span class="d-block">Comments</span>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="#" class="eagle-light">
                                    <span class="btn-add text-white"><i class="ion ion-ios-gear-outline rounded eagle-bg-warning"></i></span>
                                    <span class="d-block">Setting</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="sidebar-details py-4">
                        <div class="form-group position-relative">
                            <input type="text" class="form-control pl-5" placeholder="Search here...">
                            <div class="btn-search-left position-absolute">
                                <a href="#" class="eagle-light"><i class="ion-android-search"></i></a>
                            </div>
                        </div>
                        <div class="media mb-4">
                            <img src="dist/images/author2.jpg" alt="" class="d-flex mr-3 img-fluid eagle-rounded-circle-50 align-self-center" width="50">
                            <div class="media-body align-self-center eagle-line-height-1_5">
                                <span class="Montserrat">Mark Pearson</span>
                                <small class="d-block">16 min ago</small>
                            </div>
                        </div>
                        <span class="text-dark">Added File in dropbox</span>
                        <form action="/file-upload" class="dropzone dz-clickable border-0 rounded" id="my-awesome-dropzone">
                            <div class="dz-default dz-message my-0">
                                <span><img src="dist/images/dropzone.png" alt="" class="img-fluid" /></span>
                            </div>
                        </form>
                        <hr class="my-3 eagle-border-light">
                        <div class="media mb-4">
                            <img src="dist/images/author4.jpg" alt="" class="d-flex mr-3 img-fluid eagle-rounded-circle-50 align-self-center" width="50">
                            <div class="media-body align-self-center eagle-line-height-1_5">
                                <span class="Montserrat">Sean Gregory</span>
                                <small class="d-block">22 min ago</small>
                            </div>
                        </div>
                        <span class="text-dark">Upload gallery images</span>
                        <ul class="list-inline mb-0 lato sidebar-gallery">
                            <li class="list-inline-item mr-0">
                                <a href="dist/images/author1.jpg" class="btn-gallery"><img src="dist/images/author1.jpg" alt="" class="img-fluid eagle-rounded-circle-50" width="35"></a>
                            </li> 
                            <li class="list-inline-item mr-0">
                                <a href="dist/images/author2.jpg" class="btn-gallery"><img src="dist/images/author2.jpg" alt="" class="img-fluid eagle-rounded-circle-50" width="35"></a>
                            </li> 
                            <li class="list-inline-item mr-0">
                                <a href="dist/images/author3.jpg" class="btn-gallery"><img src="dist/images/author3.jpg" alt="" class="img-fluid eagle-rounded-circle-50" width="35"></a>
                            </li> 
                            <li class="list-inline-item mr-0">
                                <a href="dist/images/author4.jpg" class="btn-gallery"><img src="dist/images/author4.jpg" alt="" class="img-fluid eagle-rounded-circle-50" width="35"></a>
                            </li> 
                            <li class="list-inline-item mr-0">
                                <a href="dist/images/author5.jpg" class="btn-gallery"><img src="dist/images/author5.jpg" alt="" class="img-fluid eagle-rounded-circle-50" width="35"></a>
                            </li> 
                            <li class="list-inline-item mr-0">
                                <a href="dist/images/author6.jpg" class="btn-gallery"><img src="dist/images/author6.jpg" alt="" class="img-fluid eagle-rounded-circle-50" width="35"></a>
                            </li> 
                        </ul>
                        <hr class="my-3 eagle-border-light">
                        <div class="media mb-4">
                            <img src="dist/images/author5.jpg" alt="" class="d-flex mr-3 img-fluid eagle-rounded-circle-50 align-self-center" width="50">
                            <div class="media-body align-self-center eagle-line-height-1_5">
                                <span class="Montserrat">Luther Chapman</span>
                                <small class="d-block">30 min ago</small>
                            </div>
                        </div>
                        <span class="text-dark">Add comment</span>
                        <blockquote>
                            <p class="position-relative">Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
                        </blockquote>
                        <div class="pt-4">
                            <div class="card bg-facebook border-0 text-white mb-3">
                                <div class="card-body">
                                    <h6 class="text-white mb-0"><i class="ion-social-facebook"></i> Facebook</h6>
                                    <div class="text-center">
                                        <img src="dist/images/author2.jpg" alt="" class="img-fluid eagle-rounded-circle-50 border border-white border-width-2 mb-2" width="46"> 
                                        <span class="d-block"><a href="#" class="text-white text-uppercase font-weight-bold">Adminio admin</a></span>
                                        <small>@eadmin</small>
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                                    </div>
                                </div>
                            </div>
                            <div class="card bg-twitter border-0 text-white">
                                <div class="card-body">
                                    <h6 class="text-white mb-0"><i class="ion-social-twitter"></i> Twitter</h6>
                                    <div class="text-center">
                                        <img src="dist/images/author10.jpg" alt="" class="img-fluid eagle-rounded-circle-50 border border-white border-width-2 mb-2" width="46"> 
                                        <span class="d-block"><a href="#" class="text-white text-uppercase font-weight-bold">Adminio admin</a></span>
                                        <small>@eadmin</small>
                                        Best Responsive Admin  Dashboard Templates from 2018 http://enva.to/RxkJg 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>
            </div>