

<?php
session_start();
?>


<?php


global $barcode;
global $mobiles;
global $color;
global $model;
global $ram;
global $storage;
global $battery;
global $camera;
global $display;
global $expandable;
global $category;
global $processor;
global $price;
global $mrp;
global $Warranty;
global $ime;
global $paid;
global $balance;

$_POST['user']=$_SESSION["user"];


$user=$_POST['user'];




$_POST['billperson']=$_SESSION["cus_email"];


$billperson=$_POST['billperson'];













$_POST['address']=$_SESSION["address"];


$address=$_POST['address'];



$_POST['email']=$_SESSION["email"];


$email=$_POST['email'];


$_POST['mobileno']=$_SESSION["mobileno"];


$mobileno=$_POST['mobileno'];



$mobiles=$_POST['mobiles'];
$color=$_POST['color'];
$model=$_POST['model'];
$ram=$_POST['ram'];
$storage=$_POST['storage'];
$battery="cancelled";
$camera="cancelled";
$display="cancelled";
$processor="cancelled";
$expandable=$_POST['expandable'];
$category=$_POST['category'];


$price=$_POST['price'];
$mrp=$_POST['mrp'];
$Warranty=$_POST['Warranty'];
$qty=$_POST['qty'];
$discount=$_POST['discount'];
$total=$_POST['total'];
$gtotal=$_POST['gtotal'];
$barcode=$_POST['barcode'];
$ime=$_POST['ime'];
$paid=$_POST['paid'];
$balance=$_POST['balance'];

include'dbconfig.php';

$date1=date('Y/m/d');

date_default_timezone_set('Asia/Kolkata');
$time1 = date( ' h:i A', time () );
//echo $currentTime;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}











$sql4 = "SELECT cus_name FROM emp_details WHERE cus_email='$billperson'";
$result4 = $conn->query($sql4);



if ($result4->num_rows != 0) {
    // output data of each row
    while($row4 = $result4->fetch_assoc()) {


$billname=$row4['cus_name'];







}
}























$sql = "INSERT INTO bill (barcode,customer,address,mobile,email,mobiles,color,model,ram,storage,battery,camera,display,expandable,Category,processor,price,mrp,Warranty,date1,time1,qty,total,discount,gtotal,ime,billing_person,paid,balance) 
VALUES ('$barcode','$user','$address','$mobileno','$email','$mobiles','$color','$model','$ram','$storage','$battery','$camera','$display','$expandable','$category','$processor','$price','$mrp','$Warranty','$date1','$time1','$qty','$total','$discount','$gtotal','$ime','$billname','$paid','$balance')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}








// $sql4 = "SELECT stock FROM stock WHERE mobiles='$mobiles' and model='$model'";
// $result4 = $conn->query($sql4);



// if ($result4->num_rows > 0) {
//     // output data of each row
//     while($row4 = $result4->fetch_assoc()) {


//         echo  $row4["stock"];

// $hy=$row4["stock"];

// $hu1=(int)$hy;

//     }
// } else {
//     echo "0 results";
// } 




$sql = "SELECT * FROM stock WHERE barcode='$barcode'    ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $stock1=$row["stock"];
        $purchaseprice=$row["purchaseprice"];
        $total=$row["total"];
    }
} else {
    
} 
$stock=$stock1 - $qty;
$pprice=$purchaseprice * $qty;
$total1=$total - $pprice;
// $minu=$hu1-(int)$qty;

// echo $minu;
// echo "<br>";
// echo $color;
$sql1 = "UPDATE stock SET stock='$stock',total='$total1' WHERE barcode='$barcode' ";
if ($conn->query($sql1) === TRUE) {
  echo "New record Updated successfully";

} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}






echo $gtotal;

$yut=(int)$gtotal;


if ($yut>=2000){
    
    
    $yts=$yut/2000;
    
    echo round($yts);






$poi=round($yts);

$ami=1000;

$tt=$poi*$ami;



$sql4 = "SELECT customer FROM creditpoint WHERE customer='$user'";
$result4 = $conn->query($sql4);



if ($result4->num_rows != 0) {
    // output data of each row
    while($row4 = $result4->fetch_assoc()) {


    $sql = "UPDATE creditpoint SET point=point+'$poi',total=total+'$tt',date1='$date1' WHERE customer='$user'"; 
if ($conn->query($sql) === TRUE) {
  echo "user already exists!";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}


    }
} else {
    
    $sql = "INSERT INTO creditpoint (customer,point,amount,total,date1,mobile) 
VALUES ('$user','$poi','$ami','$tt','$date1','$mobileno')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}


    
} 






























    
    
}





$conn->close

();


// header("Location: https://snowaqua.starkings.in/mt5/software/main.php");
header("Location:https://papoosekart.staging-rdegi.com//bbb.php");
  


?>





