<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=0">

    <!-- BOOTSTRAP ONLINE CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <title>Invoice Bill</title>
    <style type="text/css">
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .page{
            background: white;
            border: 4px solid black;
            margin-top: 1em;
            margin-bottom: 1em;
            height: auto;
            overflow:hidden;
            position: relative;
        }

        .clearfix{
            margin-top: 3em;
        }

        .pe-none{
          color: black;
          position: absolute;
          right: 6.5rem;
        }

        .sec-4 p{
          margin-right: 9rem !important;
        }

        ..sec-4 p a{
          display: flex;
          justify-content: center;
          text-align: center;
        }

        #row-bottom-border{
            border-bottom: 2px solid black;
            /* margin-bottom: .8em; */
        }
        .row-top-border{
            border-top: 2px solid black;
        }
        .row .section-1{
            padding: 1em;
        }
        .row .section-1 h5{
            font-family: 'Open Sans', sans-serif;
        }
        .row .col-sm-6 #image{
            width: 5%;
            height: auto;
        }
        .row .col-sm-6 img{
            max-width: 13em;
            max-height: 8em;
            position: absolute;
            top: 70px;
            right: 40px
        }
        .section-6-border{
            border-right: 2px solid black;
        }
   .list-group-item {
   padding: 0rem 0rem!important;
   }

    </style>
</head>

<?php 
include'dbconfig.php';

global $pribi1;

global $qtybi;



global $pribi2;

global $qtybi2;

global $pribi4;

global $qtybi4;


global $pribi6;

global $qtybi6;
$_POST['user']=$_SESSION["user"];


$cn=$_POST['user'];


$_POST['date11']=$_SESSION["date11"];


$dn=$_POST['date11'];

$_POST['time11']=$_SESSION["time11"];


$tn=$_POST['time11'];

$_POST['time11']=$_SESSION[""];

$_POST['ids']=$_SESSION["ids"];
$id=$_POST['ids'];

$tn=$_POST['time11'];
$date1=date('Y/m/d');
$time1=date('h:i:sa');


$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql100 = "TRUNCATE TABLE temp_invoice";
if ($conn->query($sql100) === TRUE) {
  // echo "Record deleted successfully";
} else {
  // echo "Error deleting record: " . $conn->error;
}

?>
<body>
      <script type="text/javascript" src="http://jqueryjs.googlecode.com/files/jquery-1.3.1.min.js"> </script>
    <script language="javascript" type="text/javascript">
         
        function printDiv(divID) {
            //Get the HTML of div
            var divElements = document.getElementById(divID).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML =
                "<html><head><title></title></head><body>" +
                divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;


        }
    </script>
  <?php
include'dbconfig.php';
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * from bill where id='$id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  $counter = 0;
  while ($row1 = $result->fetch_assoc()) {
   $brand=$row1['mobiles'];
   $model=$row1['model'];
   $price=$row1['price'];
   $qty=$row1['qty'];
   $gtotal=$row1['gtotal'];
   $total=$row1['total'];
   $discount=$row1['discount'];
   $date=$row1['date1'];
   $time=$row1['time1'];
   $address=$row1['address'];
   $warrenty=$row1['Warranty'];
   $id=$row1['id'];
   $email=$row1['email'];
   $color=$row1['color'];
    $newDate = date("d-m-Y", strtotime($date));
  }}
  ?>
  <input type="button" class="mx-2 mt-5" value="Print Invoice" id="but" onclick="javascript:printDiv('printablediv')" /> 
    <div id="printablediv">
  <div class="card">
  <div class="card-body">
    <div class="container">
      <div class="row d-flex align-items-baseline">
                       <div class="col-8 section-1">
                    <h5 class="fs-4 fw-"style="color:#5d9fc5">Inventory Management</h5>
                    <p class="address fw-light">No.55,Sri Devi Karumariyamman Nagar,<br> Kolladi Road, Opp.Post Office,<br> Thiruverkadu,Chennai-600077</p>
                    <p class="gst-no fw-bold">GSTIN/UIN : <a href="#" class="text-decoration-none fw-bold" style= "color: black">33DLTPS2755F1ZN</a></p>
                    <p class="mobile-no fw-bold">Mobile No: <span>9962452929</span></p>    
                </div>
                <div class="col-4 my-auto"id="image">
                    <img src="dist/images/Papoose_Logo2.png" class="" alt="Snow Aqua width="200" height="200" ">
                </div>    
        <hr>
      </div>
      <div class="container">
        <div class="col-md-12">
          <div class="text-center">
            <i class="fab fa-mdb fa-4x ms-0" style="color:#5d9fc5 ;"></i>
            <!--<p class="pt-0">MDBootstrap.com</p>-->
          </div>

        </div>
        <div class="row">
          <div class="col-8 ">
            <ul class="list-unstyled">
              <li class="text-muted">To: <span style="color:#5d9fc5 ;"><?php echo $_SESSION["user"] ?></span></li>
              <li class="text-muted">Address:<?php echo $address ?></li>
              <li class="text-muted">Mobile:<i class="fas fa-phone"></i><?php echo $_SESSION["mobileno"]?></li>
            </ul>
          </div>
          <div class="col-4 ">
            <p class="text-muted">Invoice</p>
            <ul class="list-unstyled">
              <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i> <span
                  class="fw-bold">ID:</span>#<?php echo $id?></li>
              <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i> <span
                  class="fw-bold">Creation Date: </span><?php echo $newDate ?></li>
             <!--<li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i> <span
                  class="me-1 fw-bold">Status:</span><span class="badge bg-warning text-black fw-bold">
                  Unpaid</span></li>-->
            </ul>
          </div>
        </div>

        <div class="row my-2 mx-1 justify-content-center">
          <table class="table table-striped table-borderless">
            <thead style="background-color:#84B0CA ;" class="text-white">
              <tr>
                <th scope="col">#</th>
                <th scope="col">Product</th>
                <th scope="col">Model</th>
                <th scope="col">Qty</th>
                <th scope="col">Amount</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td><?php echo $brand?></td>
                <td><?php echo $model?></td>
                <td><?php echo $qty?></td>
                <td><?php echo $total?></td>
              </tr>
            </tbody>

          </table>
        </div>
        <div class="row">
          <div class="col-6">
            <ul class="list-unstyled">
              <li class="text-muted">Color: <span style="color:#5d9fc5 ;"><?php echo $color ?></span></li>
              <li class="text-muted">Warrenty:<?php echo $warrenty ?></li>
              <li class="text-muted">Email:<i class="fas fa-phone"></i><?php echo $email?></li>
            </ul>
          </div>
          <div class="col-6 ">
            <div class="float-xl-end">
             <ul class="list-unstyled ">
              <li class="text-muted ms-3"><span class="text-black me-4">Total :</span>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $total?></li>
              <li class="text-muted ms-3"><span class="text-black me-4">Discount :</span><?php echo $discount?></li>
            </ul>
            <p class="text-black "><span class="text-black me-3">Grand Total :</span><span
                style="font-size: 25px;"><?php echo $gtotal?></span></p>
            </div>
          </div>
        </div>
        <hr>
        <div class="row">
          <div class="col-xl-10">
            <p>Thank you for your purchase</p>
          </div>
          <!--<div class="col-xl-2">
            <button type="button" class="btn btn-primary text-capitalize"
              style="background-color:#60bdf3 ;">Pay Now</button>
          </div>-->
        </div>

      </div>
    </div>
  </div>
</div>
</div>


    <!-- BOOTSTRAP ONLINE CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
</body>
</html>